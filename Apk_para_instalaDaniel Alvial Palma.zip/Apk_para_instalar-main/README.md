# Apk_para_instalar

este es el instalable de la pestaña Build -> Generate Signed Bundle



